<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerSubscriptionsController extends Controller
{
    public function purchase_subscription(Request $request){
        

    }
}
